package password;

public class Password {
	// MonkeyLearn API
	public static final String APIkeyword = "28a9ff68efb8dbec19934f96a16b9e79de877224";
	public static final String ModelID = "ex_YCya9nrn";
	
	// MySQL password
	private static final String INSTANCE = "laiproject-instance.cxxdtwwwr1iy.us-east-2.rds.amazonaws.com";
	private static final String PORT_NUM = "3306";
	public static final String DB_NAME = "laiproject";
	private static final String USERNAME = "admin";
	private static final String PASSWORD = "sxm1102--";
	public static final String URL = "jdbc:mysql://"
			+ INSTANCE + ":" + PORT_NUM + "/" + DB_NAME
			+ "?user=" + USERNAME + "&password=" + PASSWORD
			+ "&autoReconnect=true&serverTimezone=UTC";
}
